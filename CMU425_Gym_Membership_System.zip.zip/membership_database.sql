-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 07, 2026 at 01:40 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `membership_database`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetMemberBookings` (IN `member_id` INT)   BEGIN
    SELECT Members.FirstName, Classes.ClassName, Classes.StartTime
    FROM ClassBookings
    JOIN Members ON ClassBookings.MemberID = Members.MemberID
    JOIN Classes ON ClassBookings.ClassID = Classes.ClassID 
    WHERE Members.MemberID = member_id;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `attendancelog`
--

CREATE TABLE `attendancelog` (
  `LogID` int(11) NOT NULL,
  `BookingID` int(11) DEFAULT NULL,
  `CheckInTime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendancelog`
--

INSERT INTO `attendancelog` (`LogID`, `BookingID`, `CheckInTime`) VALUES
(1, 1, '2026-04-01 09:00:00'),
(2, 2, '2026-04-01 18:00:00'),
(3, 3, '2026-04-01 18:00:00'),
(4, 4, '2026-04-01 09:00:00'),
(5, 5, '2026-04-02 10:00:00'),
(6, 6, '2026-04-02 17:00:00'),
(7, 9, '2026-03-23 09:18:23'),
(8, 10, '2026-03-29 20:50:15'),
(9, 11, '2026-03-29 20:50:15'),
(10, 12, '2026-03-29 20:50:15'),
(11, 13, '2026-03-29 20:50:15'),
(12, 14, '2026-03-29 20:50:15'),
(13, 15, '2026-03-29 20:50:15'),
(14, 16, '2026-03-29 20:50:15'),
(15, 17, '2026-03-29 20:50:15'),
(16, 18, '2026-03-29 20:50:15'),
(17, 19, '2026-03-29 20:50:15'),
(21, 20, '2026-04-01 17:06:27'),
(22, 21, '2026-04-01 17:07:17');

--
-- Triggers `attendancelog`
--
DELIMITER $$
CREATE TRIGGER `ValidateAttendance` BEFORE INSERT ON `attendancelog` FOR EACH ROW BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM ClassBookings WHERE BookingID = NEW.BookingID
    ) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Invalid BookingID: Cannot log attendance';
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `classbookings`
--

CREATE TABLE `classbookings` (
  `BookingID` int(11) NOT NULL,
  `MemberID` int(11) DEFAULT NULL,
  `ClassID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `classbookings`
--

INSERT INTO `classbookings` (`BookingID`, `MemberID`, `ClassID`) VALUES
(1, 1, 1),
(2, 2, 2),
(3, 1, 2),
(4, 2, 1),
(5, 3, 2),
(6, 4, 1),
(7, 5, 3),
(8, 6, 4),
(9, 1, 2),
(10, 1, 2),
(11, 2, 1),
(12, 3, 1),
(13, 4, 2),
(14, 5, 3),
(15, 6, 1),
(16, 3, 2),
(17, 4, 3),
(18, 2, 3),
(19, 5, 1),
(20, 1, 2),
(21, 1, 2);

--
-- Triggers `classbookings`
--
DELIMITER $$
CREATE TRIGGER `AutoAttendance` AFTER INSERT ON `classbookings` FOR EACH ROW BEGIN
    INSERT INTO AttendanceLog (BookingID, CheckInTime)
    VALUES (NEW.BookingID, NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE `classes` (
  `ClassID` int(11) NOT NULL,
  `ClassName` varchar(100) DEFAULT NULL,
  `TrainerID` int(11) DEFAULT NULL,
  `StartTime` datetime DEFAULT NULL,
  `Capacity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`ClassID`, `ClassName`, `TrainerID`, `StartTime`, `Capacity`) VALUES
(1, 'Morning Yoga', 1, '2026-04-01 09:00:00', 15),
(2, 'Evening Cardio', 2, '2026-04-01 18:00:00', 20),
(3, 'Pilates', 3, '2026-04-02 10:00:00', 12),
(4, 'Strength Training', 4, '2026-04-02 17:00:00', 15),
(5, 'Cardio Blast', 5, '2026-04-03 18:00:00', 20),
(6, 'Hiit', 1, '2026-04-02 10:00:00', 15),
(7, 'Spin Class', 2, '2026-04-02 12:00:00', 20),
(8, 'Strength Training', 2, '2026-04-03 14:00:00', 18);

-- --------------------------------------------------------

--
-- Stand-in structure for view `memberclassview`
-- (See below for the actual view)
--
CREATE TABLE `memberclassview` (
`FirstName` varchar(50)
,`LastName` varchar(50)
,`ClassName` varchar(100)
,`StartTime` datetime
);

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `MemberID` int(11) NOT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `TierID` int(11) DEFAULT NULL,
  `JoinDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`MemberID`, `FirstName`, `LastName`, `Email`, `TierID`, `JoinDate`) VALUES
(1, 'John', 'Doe', 'john@example.com', 2, '2026-03-01'),
(2, 'Alice', 'Smith', 'alice@example.com', 1, '2026-03-05'),
(3, 'Michael', 'Ali', 'michael@email.com', 1, '2026-03-10'),
(4, 'Sophie', 'Khan', 'sophie@email.com', 2, '2026-03-12'),
(5, 'Daniel', 'Smith', 'daniel@email.com', 3, '2026-03-15'),
(6, 'Aisha', 'Rahman', 'aisha@email.com', 4, '2026-03-18'),
(7, 'Sophie', 'Ali', 'sophie@example.com', 1, '2026-03-10'),
(8, 'Michael', 'Khan', 'michael@example.com', 2, '2026-03-12'),
(9, 'Aisha', 'Rahman', 'aisha@example.com', 1, '2026-03-15'),
(10, 'Daniel', 'Smith', 'daniel@example.com', 2, '2026-03-18'),
(11, 'Zahra', 'Hussain', 'zahra@example.com', 1, '2026-03-20');

-- --------------------------------------------------------

--
-- Table structure for table `membershiptiers`
--

CREATE TABLE `membershiptiers` (
  `TierID` int(11) NOT NULL,
  `TierName` varchar(50) DEFAULT NULL,
  `Price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `membershiptiers`
--

INSERT INTO `membershiptiers` (`TierID`, `TierName`, `Price`) VALUES
(1, 'Basic', 25.00),
(2, 'Premium', 50.00),
(3, 'Student', 15.00),
(4, 'VIP', 70.00);

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `PaymentID` int(11) NOT NULL,
  `MemberID` int(11) DEFAULT NULL,
  `Amount` decimal(10,2) DEFAULT NULL,
  `PaymentDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`PaymentID`, `MemberID`, `Amount`, `PaymentDate`) VALUES
(1, 1, 50.00, '2026-03-01'),
(2, 2, 25.00, '2026-03-05'),
(3, 3, 50.00, '2026-03-07'),
(4, 4, 25.00, '2026-03-10'),
(5, 5, 15.00, '2026-03-12'),
(6, 6, 70.00, '2026-03-15'),
(7, 3, 25.00, '2026-03-10'),
(8, 4, 50.00, '2026-03-12'),
(9, 5, 25.00, '2026-03-15'),
(10, 6, 50.00, '2026-03-18');

-- --------------------------------------------------------

--
-- Table structure for table `trainers`
--

CREATE TABLE `trainers` (
  `TrainerID` int(11) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Speciality` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `trainers`
--

INSERT INTO `trainers` (`TrainerID`, `Name`, `Speciality`) VALUES
(1, 'Sarah Jenkins', 'Yoga'),
(2, 'Mike Ross', 'Cardio'),
(3, 'Emma Wilson', 'Pilates'),
(4, 'David Khan', 'Strength'),
(5, 'Olivia Brown', 'Cycling');

-- --------------------------------------------------------

--
-- Structure for view `memberclassview`
--
DROP TABLE IF EXISTS `memberclassview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `memberclassview`  AS SELECT `members`.`FirstName` AS `FirstName`, `members`.`LastName` AS `LastName`, `classes`.`ClassName` AS `ClassName`, `classes`.`StartTime` AS `StartTime` FROM ((`classbookings` join `members` on(`classbookings`.`MemberID` = `members`.`MemberID`)) join `classes` on(`classbookings`.`ClassID` = `classes`.`ClassID`)) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendancelog`
--
ALTER TABLE `attendancelog`
  ADD PRIMARY KEY (`LogID`),
  ADD KEY `BookingID` (`BookingID`);

--
-- Indexes for table `classbookings`
--
ALTER TABLE `classbookings`
  ADD PRIMARY KEY (`BookingID`),
  ADD KEY `MemberID` (`MemberID`),
  ADD KEY `ClassID` (`ClassID`);

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`ClassID`),
  ADD KEY `TrainerID` (`TrainerID`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`MemberID`),
  ADD KEY `TierID` (`TierID`);

--
-- Indexes for table `membershiptiers`
--
ALTER TABLE `membershiptiers`
  ADD PRIMARY KEY (`TierID`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`PaymentID`),
  ADD KEY `MemberID` (`MemberID`);

--
-- Indexes for table `trainers`
--
ALTER TABLE `trainers`
  ADD PRIMARY KEY (`TrainerID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendancelog`
--
ALTER TABLE `attendancelog`
  MODIFY `LogID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `classbookings`
--
ALTER TABLE `classbookings`
  MODIFY `BookingID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `classes`
--
ALTER TABLE `classes`
  MODIFY `ClassID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `MemberID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `membershiptiers`
--
ALTER TABLE `membershiptiers`
  MODIFY `TierID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `PaymentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `trainers`
--
ALTER TABLE `trainers`
  MODIFY `TrainerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendancelog`
--
ALTER TABLE `attendancelog`
  ADD CONSTRAINT `attendancelog_ibfk_1` FOREIGN KEY (`BookingID`) REFERENCES `classbookings` (`BookingID`);

--
-- Constraints for table `classbookings`
--
ALTER TABLE `classbookings`
  ADD CONSTRAINT `classbookings_ibfk_1` FOREIGN KEY (`MemberID`) REFERENCES `members` (`MemberID`),
  ADD CONSTRAINT `classbookings_ibfk_2` FOREIGN KEY (`ClassID`) REFERENCES `classes` (`ClassID`);

--
-- Constraints for table `classes`
--
ALTER TABLE `classes`
  ADD CONSTRAINT `classes_ibfk_1` FOREIGN KEY (`TrainerID`) REFERENCES `trainers` (`TrainerID`);

--
-- Constraints for table `members`
--
ALTER TABLE `members`
  ADD CONSTRAINT `members_ibfk_1` FOREIGN KEY (`TierID`) REFERENCES `membershiptiers` (`TierID`);

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`MemberID`) REFERENCES `members` (`MemberID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
