Gym Membership Database - ReadMe 

This project is a relational database management system (RDBMS) designed for a gym membership environment. It was developed as part of the CMU425 module and demonstrates the full database lifecycle including analysis, design, implementation, testing, and evaluation.

The system manages core gym operations including:

Member registration and membership tiers
Trainer management
Class scheduling
Class bookings
Attendance tracking
Payment processing

It uses MySQL (phpMyAdmin/XAMPP) for the database and a Python Tkinter GUI for user interaction.

Technologies Used
MySQL (phpMyAdmin via XAMPP)
SQL (DDL, DML, JOINs, Triggers, Views)
Python 3
Tkinter (GUI library)
mysql-connector-python

Database Structure

The system consists of the following tables:

MembershipTiers (TierID, TierName, Price)
Members (MemberID, Name, Email, TierID, JoinDate)
Trainers (TrainerID, Name, Speciality)
Classes (ClassID, ClassName, TrainerID, StartTime, Capacity)
ClassBookings (BookingID, MemberID, ClassID)
AttendanceLog (LogID, BookingID, CheckInTime)
Payments (PaymentID, MemberID, Amount, PaymentDate)

Relationships are enforced using primary and foreign keys to ensure referential integrity.

Features of the Database

Fully normalised database (up to 3NF)
Using foreign keys to maintain referential integrity
Trigger-based automated attendance monitoring
JOIN searches for data retrieval
Aggregation using COUNT and GROUP BY
Views for simplified reporting

Features of the Python GUI

Add new members
View classes and members
Schedule classes for members
Real-time database results display

How to Run the Project

1. Start Database
Open XAMPP
Start Apache and MySQL
Open phpMyAdmin
Import the provided SQL script

2. Install Python Requirements

Run the following command: pip install mysql-connector-python 

3. Run the Application

Open terminal in VS Code and run: membership_database_gui.py

Important Notes
Ensure the database name is: membership_database
XAMPP MySQL must be running before launching the GUI
IDs (MemberID, ClassID, TierID) must exist in database tables before use

Testing

The system has been tested for:

Valid and invalid data entry
Foreign key constraint enforcement
Trigger functionality (automatic attendance logging)
SQL query accuracy


Example Functionality

A member registers and is assigned a membership tier
The member books a class using ClassBookings
Attendance is automatically logged using a trigger
Payments are recorded and linked to the member profile





