import tkinter as tk
from tkinter import messagebox
import mysql.connector

# ---------------- DATABASE CONNECTION ----------------
def connect_db():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",   # XAMPP default is empty
        database="membership_database"
    )

# ---------------- FUNCTIONS ----------------

def view_members():
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT MemberID, FirstName, LastName, Email, TierID, JoinDate
        FROM Members
    """)
    rows = cursor.fetchall()

    output.delete("1.0", tk.END)
    for row in rows:
        output.insert(tk.END, f"{row}\n")

    conn.close()


def add_member():
    conn = connect_db()
    cursor = conn.cursor()

    query = """
        INSERT INTO Members (FirstName, LastName, Email, TierID, JoinDate)
        VALUES (%s, %s, %s, %s, %s)
    """

    data = (
        entry_first.get(),
        entry_last.get(),
        entry_email.get(),
        entry_tier.get(),
        entry_date.get()
    )

    cursor.execute(query, data)
    conn.commit()
    conn.close()

    messagebox.showinfo("Success", "Member added successfully!")


def view_classes():
    conn = connect_db()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT Classes.ClassID, ClassName, Name, StartTime, Capacity
        FROM Classes
        JOIN Trainers ON Classes.TrainerID = Trainers.TrainerID
    """)

    rows = cursor.fetchall()

    output.delete("1.0", tk.END)
    for row in rows:
        output.insert(tk.END, f"{row}\n")

    conn.close()


def book_class():
    conn = connect_db()
    cursor = conn.cursor()

    query = """
        INSERT INTO ClassBookings (MemberID, ClassID)
        VALUES (%s, %s)
    """

    data = (
        entry_member_id.get(),
        entry_class_id.get()
    )

    cursor.execute(query, data)
    conn.commit()
    conn.close()

    messagebox.showinfo("Success", "Class booked successfully!")

# ---------------- GUI SETUP ----------------

root = tk.Tk()
root.title("Gym Management System")
root.geometry("800x600")

# ---------------- INPUT FIELDS ----------------

tk.Label(root, text="First Name").grid(row=0, column=0)
entry_first = tk.Entry(root)
entry_first.grid(row=0, column=1)

tk.Label(root, text="Last Name").grid(row=1, column=0)
entry_last = tk.Entry(root)
entry_last.grid(row=1, column=1)

tk.Label(root, text="Email").grid(row=2, column=0)
entry_email = tk.Entry(root)
entry_email.grid(row=2, column=1)

tk.Label(root, text="Tier ID").grid(row=3, column=0)
entry_tier = tk.Entry(root)
entry_tier.grid(row=3, column=1)

tk.Label(root, text="Join Date (YYYY-MM-DD)").grid(row=4, column=0)
entry_date = tk.Entry(root)
entry_date.grid(row=4, column=1)

tk.Button(root, text="Add Member", command=add_member).grid(row=5, column=1)

# ---------------- BOOKING ----------------

tk.Label(root, text="Member ID").grid(row=6, column=0)
entry_member_id = tk.Entry(root)
entry_member_id.grid(row=6, column=1)

tk.Label(root, text="Class ID").grid(row=7, column=0)
entry_class_id = tk.Entry(root)
entry_class_id.grid(row=7, column=1)

tk.Button(root, text="Book Class", command=book_class).grid(row=8, column=1)

# ---------------- BUTTONS ----------------

tk.Button(root, text="View Members", command=view_members).grid(row=9, column=0)
tk.Button(root, text="View Classes", command=view_classes).grid(row=9, column=1)

# ---------------- OUTPUT BOX ----------------

output = tk.Text(root, height=15, width=90)
output.grid(row=10, column=0, columnspan=2)

root.mainloop()



